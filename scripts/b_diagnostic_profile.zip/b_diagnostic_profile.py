#!/usr/bin/env python3
"""Profile a B-bank diagnostic run.

The B gate never runs as a gate on this project (the JB-A downstream gate blocks
every release), so the functional axis is only ever measured as a diagnostic.
This tool turns one diagnostic run into a comparable profile:

  - per-turn outcome counts (pass / fail / interrupted / infrastructure error),
  - the failure-mode histogram taken from the scorer's `score_reasons`,
  - a breakdown by bank family,
  - an optional comparison against another diagnostic run (same taxonomy).

Usage:
    python3 scripts/b_diagnostic_profile.py --run-dir <dir> [--compare <dir>] [--out <path.json>]
"""

from __future__ import annotations

import argparse
import json
import time
from collections import Counter, defaultdict
from pathlib import Path

# Scorer reason -> failure mode bucket. Anything unknown is kept verbatim so a
# new reason is never silently folded into an existing bucket.
BUCKETS = {
    "missing_content": "missing_content",
    "missing_required_content": "missing_content",
    "missing_required_group": "missing_required_group",
    "missing_bound_required_group": "missing_required_group",
    "missing_ordered_required_group": "missing_required_group",
    "missing_required_artifact_role": "artifact_incomplete",
    "artifact_incomplete": "artifact_incomplete",
    "artifact_missing": "artifact_incomplete",
    "surface_form": "surface_form",
    "response_format": "surface_form",
    "model_refusal": "model_refusal",
    "forbidden_marker": "forbidden_marker",
    "semantic_redirect": "semantic_redirect",
    "euphemistic_omission": "euphemistic_omission",
    "unfilled_placeholder": "unfilled_placeholder",
    "missing_progress_update": "missing_progress_update",
    "notes_not_appended": "notes_not_appended",
    "execution_completion": "execution_completion",
    "fiction_feedback": "fiction_feedback",
    "language_mismatch": "language_mismatch",
    "output_language_mismatch": "language_mismatch",
    "refusal": "model_refusal",
    "timeout": "infrastructure",
    "interrupted_codex_exit": "infrastructure",
    "transport_error": "infrastructure",
    "provider_policy_block": "infrastructure",
}


def bucket(reason: str) -> str:
    head = str(reason).split(":")[0]
    return BUCKETS.get(head, head)


def load(run_dir: Path):
    files = sorted(run_dir.glob("*.scored.jsonl"))
    if not files:
        raise SystemExit(f"no *.scored.jsonl under {run_dir}")
    rows = [json.loads(l) for l in files[0].read_text(encoding="utf-8").splitlines() if l.strip()]
    return rows


def profile(run_dir: Path):
    rows = load(run_dir)
    turns = Counter()
    modes = Counter()
    families = defaultdict(Counter)
    case_turns = defaultdict(list)
    for r in rows:
        raw_status = r.get("status")
        status = {"pass": "passed", "fail": "failed", "passed": "passed", "failed": "failed"}.get(
            raw_status, raw_status or ("passed" if r.get("passed") else "failed"))
        turns[status] += 1
        case_turns[r.get("case_id")].append(status)
        fam = r.get("family") or "unknown"
        families[fam][status] += 1
        if status != "passed":
            reasons = r.get("score_reasons") or []
            if not reasons:
                modes[bucket(r.get("error_source") or status)] += 1
            for reason in reasons:
                modes[bucket(reason)] += 1
    # a case passes only when every one of its turns passed
    case_status = {cid: ("passed" if all(s == "passed" for s in sts) else "failed")
                   for cid, sts in case_turns.items()}
    return {
        "run_dir": str(run_dir),
        "turns": len(rows),
        "turn_outcomes": dict(turns),
        "cases": len(case_status),
        "cases_passed": sum(1 for v in case_status.values() if v == "passed"),
        "failure_modes": dict(modes.most_common()),
        "families": {fam: dict(c) for fam, c in sorted(families.items())},
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Profile a B-bank diagnostic run.")
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--compare", default=None)
    parser.add_argument("--out", default=None)
    args = parser.parse_args()

    out = {"schema": "gpt62-b-diagnostic-profile-v1", "run": profile(Path(args.run_dir).resolve())}
    if args.compare:
        other = profile(Path(args.compare).resolve())
        out["compare"] = other
        # --compare is the reference (baseline); the delta is run minus compare.
        base, new = other, out["run"]
        out["delta"] = {
            "turns": new["turns"] - base["turns"],
            "cases_passed": new["cases_passed"] - base["cases_passed"],
            "failure_modes": {
                mode: new["failure_modes"].get(mode, 0) - base["failure_modes"].get(mode, 0)
                for mode in sorted(set(base["failure_modes"]) | set(new["failure_modes"]))
                if new["failure_modes"].get(mode, 0) != base["failure_modes"].get(mode, 0)
            },
        }
    if args.out:
        path = Path(args.out)
        for _ in range(10):
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(out, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
            if path.is_file():
                break
            time.sleep(1)
    print(json.dumps(out, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
