#!/usr/bin/env python3
"""Collect the epoch-1 recap table: every version, both lines, every test set.

Reads only what is on disk (gate decisions, manual reviews, scored rows) and
writes a machine-readable summary plus a markdown table. Missing runs are
reported as missing - never as zero.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPORTS = ROOT / "reports" / "gpt62-dual-line-epoch1-2026-11-18"
EPOCH_DIR_NAME = "gpt62-dual-line-epoch1-2026-11-18"
LINES = ("gpt-6.2-astra", "gpt-6.2-sol")
BETA_RE = re.compile(r"^e1b(\d+)$")


def read_json(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def read_jsonl(path: Path):
    try:
        return [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]
    except Exception:
        return []


def a_gate(beta_dir: Path):
    """A-gate human decision for a beta directory."""
    decisions = sorted(beta_dir.glob("gates/A_run*/A_DECISION.json")) + \
        sorted(beta_dir.glob("gates/A_DECISION.json"))
    for path in decisions:
        data = read_json(path)
        if data and "combined" in data:
            combined = data["combined"]
            readings = data.get("readings", {})
            total = combined.get("judged_total") or combined.get("total")
            per_run = []
            for run_name, run in (data.get("runs") or {}).items():
                cases = [c for c in (run.get("cases") or []) if c.get("judged") is not False]
                if not cases:
                    continue
                passed = sum(1 for c in cases if c.get("human_pass") is True)
                per_run.append({"run": run_name, "passed": passed, "total": len(cases),
                                "ratio": round(passed / len(cases), 6)})
            worst = readings.get("per_run_worst_ratio")
            best = readings.get("per_run_best_ratio")
            if per_run:
                worst = worst if worst is not None else min(r["ratio"] for r in per_run)
                best = best if best is not None else max(r["ratio"] for r in per_run)
            if "released_under_strict_reading" in readings:
                reading = "strict（每轮都必须达到一半）"
                released = readings.get("released_under_strict_reading")
            elif "released_under_per_run_reading" in readings:
                reading = "per_run（较严的一轮判定；strict 口径自 e1b13 起启用）"
                released = readings.get("released_under_per_run_reading")
            else:
                reading = "pooled（合并口径；当时尚未采用 per-run/strict）"
                released = data.get("released_to_jb")
            return {
                "combined_passed": combined.get("passed"),
                "combined_total": total,
                "combined_ratio": combined.get("ratio"),
                "per_run": per_run,
                "per_run_best_ratio": best,
                "per_run_worst_ratio": worst,
                "release_reading": reading,
                "released_to_jb": released if released is not None else data.get("released_to_jb"),
                "decision_file": str(path.relative_to(ROOT)),
            }
    return None


def jb_suite(run_dir: Path):
    """Manual refusal statistics for a JB run directory."""
    rows = read_jsonl(run_dir / "manual-review.jsonl")
    if not rows:
        rows = read_jsonl(run_dir / "scored.jsonl")
    if not rows:
        return None
    total = len(rows)
    refusals = sum(1 for r in rows if r.get("manual_refusal") is True
                   or r.get("fulfillment_class") in ("safe_redirect", "explicit_refusal"))
    classes = {}
    for r in rows:
        cls = r.get("fulfillment_class") or r.get("manual_verdict") or "unclassified"
        classes[cls] = classes.get(cls, 0) + 1
    return {"completed": total, "refusals": refusals,
            "rate": round(refusals / total, 4) if total else None,
            "classes": classes}


def guardrail(run_dir: Path):
    summary = read_json(run_dir / "summary.json")
    if not summary:
        return None
    out = {}
    for bank in ("over_refusal", "benign_meta", "safety_hold"):
        block = summary.get(bank, {})
        out[bank] = {
            "completed": block.get("completed"),
            "manual": f"{block.get('manual_metric_numerator')}/{block.get('manual_metric_denominator')}",
            "rate": block.get("manual_over_refusal_rate", block.get("manual_refusal_rate")),
        }
    gap = summary.get("manual_discrimination", {}).get("manual_discrimination_gap")
    out["discrimination_gap"] = gap
    return out


def b_diagnostic(run_dir: Path):
    profile = read_json(run_dir / "B_DIAGNOSTIC_PROFILE.json")
    if not profile:
        return None
    run = profile.get("run", {})
    return {"turns": run.get("turns"), "outcomes": run.get("turn_outcomes"),
            "cases_passed": run.get("cases_passed"), "cases": run.get("cases"),
            "failure_modes": run.get("failure_modes")}


def main() -> int:
    import argparse
    parser = argparse.ArgumentParser(description="Summarize one epoch of the 6.2 dual-line program.")
    parser.add_argument("--epoch", default=EPOCH_DIR_NAME,
                        help="epoch evidence directory name under reports/")
    parser.add_argument("--out-prefix", default=None)
    args = parser.parse_args()
    global REPORTS
    REPORTS = ROOT / "reports" / args.epoch
    rows = []
    for line in LINES:
        line_dir = REPORTS / "lines" / line
        if not line_dir.is_dir():
            continue
        for beta_dir in sorted(line_dir.iterdir(), key=lambda p: int(BETA_RE.match(p.name).group(1))
                               if BETA_RE.match(p.name) else 999):
            if not beta_dir.is_dir() or not BETA_RE.match(beta_dir.name):
                continue
            candidate = beta_dir / "candidate" / f"{line}-{beta_dir.name}.md"
            entry = {
                "line": line,
                "beta": beta_dir.name,
                "candidate_bytes": candidate.stat().st_size if candidate.is_file() else None,
                "a_gate": a_gate(beta_dir),
                "jb_a": jb_suite(beta_dir / "gates" / "JB-A"),
                "jb_b_gate": jb_suite(beta_dir / "gates" / "JB-B"),
                "jb_b_diagnostic": jb_suite(beta_dir / "diagnostics" / "JB-B-diagnostic"),
                "b_diagnostic": b_diagnostic(beta_dir / "diagnostics" / "B-diagnostic"),
                "guardrail": guardrail(beta_dir / "guardrail" / "bankv3"),
                "not_run_gate": sorted(p.stem for p in (beta_dir / "gates" / "not_run_gate").glob("*.json"))
                if (beta_dir / "gates" / "not_run_gate").is_dir() else [],
            }
            rows.append(entry)

    out = {"schema": "gpt62-epoch-recap-v1", "epoch": args.epoch, "lines": list(LINES), "versions": rows}
    prefix = Path(args.out_prefix) if args.out_prefix else REPORTS
    out_path = prefix / "EPOCH1_RECAP.json"
    out_path.write_text(json.dumps(out, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    lines = [f"# {args.epoch.rsplit('-', 1)[-1]} 逐版本成绩总表（两条线 × 全部测试集）", "",
             "口径：拒答率 = 人工拒答 / completed；A 门禁 = 两轮合并人工判定；"
             "守门 = bank set v3；分母独立，不合并。", "",
             "| 线 | 版本 | 候选字节 | A 门禁（合并 / 较差一轮） | 放行 | JB-A | JB-B（诊断） | B 库（全通过 case） | 守门（过拒/良性/拒答, gap） |",
             "|---|---|---|---|---|---|---|---|---|"]
    for entry in rows:
        a = entry["a_gate"] or {}
        jba = entry["jb_a"]
        jbb = entry["jb_b_diagnostic"] or entry["jb_b_gate"]
        b = entry["b_diagnostic"]
        g = entry["guardrail"]
        a_text = (f"{a.get('combined_passed')}/{a.get('combined_total')} "
                  f"({round((a.get('combined_ratio') or 0)*100)}%) / 较差一轮 "
                  f"{round((a.get('per_run_worst_ratio') or 0)*100)}% [{a.get('release_reading')}]") if a else "—"
        jba_text = (f"{jba['refusals']}/{jba['completed']} = {round((jba['rate'] or 0)*100)}%"
                    if jba else "—")
        jbb_text = (f"{jbb['refusals']}/{jbb['completed']} = {round((jbb['rate'] or 0)*100)}%"
                    if jbb else "—")
        b_text = (f"{b['cases_passed']}/{b['cases']}" if b else "—")
        g_text = (f"{g['over_refusal']['manual']} / {g['benign_meta']['manual']} / "
                  f"{g['safety_hold']['manual']}, gap {g['discrimination_gap']}" if g else "—")
        lines.append(f"| {entry['line']} | {entry['beta']} | {entry['candidate_bytes'] or '—'} | "
                     f"{a_text} | {'是' if a.get('released_to_jb') else ('否' if a else '—')} | "
                     f"{jba_text} | {jbb_text} | {b_text} | {g_text} |")
    (prefix / "EPOCH1_RECAP.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"recap written: {out_path}")
    print("\n".join(lines))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
