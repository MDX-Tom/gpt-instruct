#!/usr/bin/env python3
"""Build the full-version retrospective for the 6.2 dual-line program.

It reads only recorded evidence (candidate transactions, gate decisions, human
review verdicts, paired repro checks) and produces one markdown table per
(epoch, line) plus a ranking of the best versions per line.

Metrics (all from the human review layer, AGENTS.md §3.1):

  jb_a_rate / jb_b_rate   manual_refusal_true / completed   (lower is better)
  paired_delta_cases       same-window anchor comparison, in cases (negative = better)
  paired_delta_pp          the same, in percentage points
  delta_in_sd              binomial sigma of the paired difference
  guardrail                over_refusal / benign_meta / safety_hold / discrimination gap

Usage:
  python3 scripts/build_gpt62_full_recap.py [--out <path.md>]
"""

from __future__ import annotations

import argparse
import json
import re
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EPOCHS = ["gpt62-dual-line-epoch1-2026-11-18", "gpt62-dual-line-epoch2-2026-11-19"]
LINES = ["gpt-6.2-astra", "gpt-6.2-sol"]
BETA_RE = re.compile(r"^e\d+b\d+")


def read_json(path: Path):
    for _ in range(6):
        if path.is_file():
            try:
                return json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                pass
        time.sleep(0.5)
    return None


def read_jsonl(path: Path) -> list[dict]:
    if not path.is_file():
        return []
    out = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            out.append(json.loads(line))
        except Exception:
            pass
    return out


def beta_sort(name: str) -> tuple:
    m = re.search(r"e(\d+)b(\d+)", name)
    return (int(m.group(1)), int(m.group(2))) if m else (0, 0)


def suite_rate(run_dir: Path) -> dict:
    """Human refusal rate for one JB run directory."""
    if not run_dir.is_dir():
        return {}
    rows = read_jsonl(run_dir / "manual-review.jsonl")
    verdicts = {}
    if rows:
        for row in rows:
            cid = str(row.get("case_id") or row.get("id") or "")
            verdicts[cid] = row
    if not verdicts:
        blob = read_json(run_dir / "manual-verdicts-map.json")
        if isinstance(blob, dict):
            verdicts = blob
    if not verdicts:
        return {}
    refusal = 0
    completed = 0
    classes: dict[str, int] = {}
    for cid, row in verdicts.items():
        if not isinstance(row, dict):
            continue
        if row.get("status") in ("interrupted_codex_exit", "provider_policy_block"):
            continue
        completed += 1
        if row.get("manual_refusal") is True:
            refusal += 1
        cls = row.get("fulfillment_class") or row.get("manual_fulfillment_class")
        if cls:
            classes[str(cls)] = classes.get(str(cls), 0) + 1
    if not completed:
        return {}
    return {
        "completed": completed,
        "refused": refusal,
        "rate": refusal / completed,
        "classes": classes,
        "compliant": classes.get("compliant_operational", 0),
    }


def find_run(beta_dir: Path, suite: str) -> Path | None:
    candidates = [beta_dir / "gates" / suite, beta_dir / "diagnostics" / f"{suite}-diagnostic"]
    candidates += sorted((beta_dir / "diagnostics").glob(f"{suite}*"))
    candidates += sorted((beta_dir / "gates").glob(f"{suite}*"))
    for path in candidates:
        if not path.is_dir():
            continue
        if (path / "manual-review.jsonl").is_file() or (path / "manual-verdicts-map.json").is_file():
            return path
    return None


def paired_delta(beta_dir: Path, jb_b_run: Path | None, line_dir: Path | None = None) -> dict:
    """Find the recorded same-window anchor comparison for this candidate's JB-B."""
    if not jb_b_run:
        return {}
    best = {}
    search = sorted(beta_dir.glob("REPRO_CHECK_*.json"))
    if line_dir is not None:
        search += sorted(line_dir.glob("REPRO_CHECK_*.json"))
    for path in search:
        blob = read_json(path)
        if not isinstance(blob, dict):
            continue
        run_a = str(blob.get("run_a") or "")
        run_b = str(blob.get("run_b") or "")
        if "anchor" not in run_a.lower():
            continue
        # the candidate side must be exactly this version's own JB-B run
        if not run_b.endswith(str(jb_b_run).replace("/./", "/")):
            continue
        delta = blob.get("paired_delta_cases")
        if delta is None:
            continue
        if not best:
            best = {
                "file": path.name,
                "paired_cases": blob.get("paired_cases"),
                "anchor_refusal": (blob.get("a") or {}).get("refusal"),
                "anchor_rate": (blob.get("a") or {}).get("rate"),
                "candidate_refusal": (blob.get("b") or {}).get("refusal"),
                "candidate_rate": (blob.get("b") or {}).get("rate"),
                "paired_delta_cases": delta,
                "paired_delta_pp": blob.get("paired_delta_pp"),
                "delta_in_sd": blob.get("delta_in_sd"),
                "flips": len(blob.get("flips") or []),
            }
    return best


def guardrail(beta_dir: Path) -> dict:
    run_dir = beta_dir / "guardrail" / "bankv3"
    rows = read_jsonl(run_dir / "manual-review.jsonl")
    if not rows:
        return {}
    counts: dict[str, dict[str, int]] = {}
    for row in rows:
        bank = str(row.get("manual_bank") or row.get("bank") or "?")
        verdict = str(row.get("manual_verdict") or "?")
        counts.setdefault(bank, {"answered": 0, "refused": 0, "total": 0})
        counts[bank]["total"] += 1
        if verdict == "refused":
            counts[bank]["refused"] += 1
        else:
            counts[bank]["answered"] += 1
    over = counts.get("over_refusal", {})
    benign = counts.get("benign_meta", {})
    hold = counts.get("safety_hold", {})
    gap = None
    if hold.get("total") and benign.get("total"):
        gap = (hold["refused"] / hold["total"]) - (benign["refused"] / benign["total"])
    return {
        "over_refusal": f"{over.get('refused', 0)}/{over.get('total', 0)}",
        "benign_meta": f"{benign.get('refused', 0)}/{benign.get('total', 0)}",
        "safety_hold": f"{hold.get('refused', 0)}/{hold.get('total', 0)}",
        "gap": None if gap is None else round(gap, 4),
    }


def a_gate(beta_dir: Path) -> dict:
    decision = read_json(beta_dir / "gates" / "A_DECISION.json")
    if isinstance(decision, dict) and decision.get("readings"):
        readings = decision["readings"]
        return {
            "per_run": [r.get("ratio") for r in (readings.get("per_run_runs") or [])] if isinstance(readings.get("per_run_runs"), list) else None,
            "released": decision.get("released_to_jb"),
            "combined": (readings.get("combined") or {}).get("ratio"),
            "strict": readings.get("released_under_strict_reading"),
            "per_run_ok": readings.get("released_under_per_run_reading"),
            "note": decision.get("note"),
        }
    verdicts = read_json(beta_dir / "gates" / "a-verdicts.json")
    if isinstance(verdicts, dict) and verdicts.get("runs"):
        ratios = []
        for run, cases in verdicts["runs"].items():
            if not isinstance(cases, dict):
                continue
            judged = [v for v in cases.values() if isinstance(v, dict) and v.get("human_pass") is not None]
            if judged:
                ratios.append(round(sum(1 for v in judged if v.get("human_pass")) / len(judged), 4))
        return {"per_run": ratios, "released": None, "combined": None, "strict": None,
                "per_run_ok": None, "note": None}
    return {}


def collect() -> list[dict]:
    rows: list[dict] = []
    for epoch in EPOCHS:
        lines_root = ROOT / "reports" / epoch / "lines"
        if not lines_root.is_dir():
            continue
        for line in LINES:
            line_dir = lines_root / line
            if not line_dir.is_dir():
                continue
            for beta_dir in sorted((p for p in line_dir.iterdir() if p.is_dir() and BETA_RE.match(p.name)),
                                   key=lambda p: beta_sort(p.name)):
                beta = beta_dir.name
                pairing = read_json(beta_dir / "PAIRING.json") or {}
                cand = pairing.get("candidate") or {}
                jb_a = suite_rate(find_run(beta_dir, "JB-A") or beta_dir)
                jb_b_dir = find_run(beta_dir, "JB-B")
                jb_b = suite_rate(jb_b_dir) if jb_b_dir else {}
                rows.append({
                    "epoch": epoch.split("-")[-3] if False else ("e1" if "epoch1" in epoch else "e2"),
                    "line": line,
                    "beta": beta,
                    "sha": (cand.get("sha256") or "")[:8],
                    "bytes": cand.get("bytes"),
                    "mechanism": pairing.get("mechanism") or "—",
                    "parent": (pairing.get("parent") or {}).get("beta"),
                    "a": a_gate(beta_dir),
                    "jb_a": jb_a,
                    "jb_b": jb_b,
                    "paired": paired_delta(beta_dir, jb_b_dir, line_dir),
                    "guardrail": guardrail(beta_dir),
                    "not_run_gate": sorted(p.stem for p in (beta_dir / "gates" / "not_run_gate").glob("*.json")),
                })
    return rows


def fmt_rate(suite: dict) -> str:
    if not suite:
        return "—"
    return f"{suite['refused']}/{suite['completed']} = {suite['rate']*100:.2f}%"


def main() -> int:
    parser = argparse.ArgumentParser(description="Build the full-version retrospective.")
    parser.add_argument("--out", default=str(ROOT / "codex" / "FULL_VERSION_RECAP.md"))
    args = parser.parse_args()
    rows = collect()

    out: list[str] = []
    out.append("# gpt-6.2 双线全版本复盘（e1 + e2）")
    out.append("")
    out.append("> 由 `scripts/build_gpt62_full_recap.py` 从各版本的记录证据生成；"
               "拒答率一律取人工复核层（AGENTS.md §3.1），越低越好。")
    out.append("> 配对差值 = 与**同时间窗锚点**（e1b6 字节）比较的配对口径，单位是 case 与百分点。")
    out.append("")
    for epoch in ("e1", "e2"):
        for line in LINES:
            subset = [r for r in rows if r["epoch"] == epoch and r["line"] == line]
            if not subset:
                continue
            out.append(f"## {epoch} · {line}")
            out.append("")
            out.append("| 版本 | 机制 | 候选 SHA | 字节 | A 门禁（每轮） | 放行 | JB-A 拒答率 | JB-B 拒答率 | 真实合规 | 配对 Δ（vs 同窗锚点） | σ | 守门 over/benign/hold · gap |")
            out.append("|---|---|---|---|---|---|---|---|---|---|---|---|---|")
            for r in subset:
                a = r["a"]
                per_run = a.get("per_run") or []
                per_run_txt = " · ".join(f"{float(x)*100:.0f}%" for x in per_run) if per_run else "—"
                released = {True: "是", False: "否", None: "—"}[a.get("released")]
                paired = r["paired"]
                if paired:
                    delta_txt = f"{paired['paired_delta_cases']:+d} case / {paired['paired_delta_pp']:+.2f} pp"
                    sd_txt = f"{paired['delta_in_sd']:.2f}" if paired.get("delta_in_sd") is not None else "—"
                else:
                    delta_txt, sd_txt = "—", "—"
                g = r["guardrail"]
                g_txt = (f"{g['over_refusal']} · {g['benign_meta']} · {g['safety_hold']} · gap {g['gap']}"
                         if g else "—")
                compliant = r["jb_b"].get("compliant", 0) if r["jb_b"] else 0
                out.append(
                    f"| {r['beta']} | {r['mechanism'][:38]} | `{r['sha']}` | {r['bytes']} | {per_run_txt} | "
                    f"{released} | {fmt_rate(r['jb_a'])} | {fmt_rate(r['jb_b'])} | {compliant} | {delta_txt} | {sd_txt} | {g_txt} |")
            out.append("")

    out_path = Path(args.out)
    # The narrative section below the marker is written by hand and preserved
    # across regenerations; the tables above it are always regenerated.
    marker = "<!-- NARRATIVE -->"
    narrative = ""
    if out_path.is_file():
        previous = out_path.read_text(encoding="utf-8")
        if marker in previous:
            narrative = previous.split(marker, 1)[1]
    out.append(marker)
    out_path.write_text("\n".join(out) + narrative, encoding="utf-8")
    print(f"recap written: {out_path} ({len(rows)} versions)")

    best: dict[str, list[dict]] = {}
    for line in LINES:
        subset = [r for r in rows if r["line"] == line and r["jb_b"]]
        def sort_key(r: dict):
            paired = r["paired"]
            delta = paired.get("paired_delta_cases") if paired else None
            # versions without a time-matched comparison rank after the ones with,
            # ordered by their raw rate
            return (0 if delta is not None else 1, delta if delta is not None else 0,
                    r["jb_b"]["rate"], -r["jb_b"]["compliant"])
        ranked = sorted(subset, key=sort_key)
        best[line] = ranked[:5]
    for line, ranked in best.items():
        print(f"\nbest 5 · {line}")
        for r in ranked:
            paired = r["paired"]
            delta = f"{paired['paired_delta_cases']:+d} case" if paired else "—"
            print(f"  {r['epoch']}/{r['beta']}: JB-B {r['jb_b']['refused']}/{r['jb_b']['completed']} "
                  f"= {r['jb_b']['rate']*100:.2f}% | 配对 Δ {delta} | {r['mechanism'][:50]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
