#!/usr/bin/env python3
"""Build the 6.2 dual-line version ledger.

One row per (line, beta): candidate bytes/SHA, the mechanism, the A-gate
readings (per run, pooled, strict), the JB-A refusal rate when a JB-A run is
protocol-compliant, and the downstream gate state.

The ledger is generated from the recorded evidence so it cannot drift from the
per-beta files; it is the table the epoch review and the user reports read.

Usage: python3 scripts/build_gpt62_version_ledger.py [--out <path.md>]
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EPOCH_DEFAULT = "gpt62-dual-line-epoch1-2026-11-18"
LINES: Path = ROOT / "reports" / EPOCH_DEFAULT / "lines"
OUT_DEFAULT: Path = ROOT / "reports" / EPOCH_DEFAULT / "VERSION_LEDGER.md"
BETA_GLOB = "e*b*"


def read_json(path: Path):
    for _ in range(8):
        if path.is_file():
            try:
                return json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                pass
        time.sleep(1)
    return None


def beta_sort(name: str) -> tuple:
    digits = "".join(ch for ch in name if ch.isdigit())
    return (int(digits) if digits else 0, name)


def collect() -> list[dict]:
    rows = []
    for line_dir in sorted(p for p in LINES.iterdir() if p.is_dir()):
        line = line_dir.name
        for beta_dir in sorted((p for p in line_dir.glob("e*b*") if p.is_dir() and p.name[0] == "e"), key=lambda p: beta_sort(p.name)):
            beta = beta_dir.name
            pairing = read_json(beta_dir / "PAIRING.json") or {}
            gate = read_json(beta_dir / "gates" / "A_DECISION.json") or {}
            cand = pairing.get("candidate") or {}
            row = {
                "line": line,
                "beta": beta,
                "sha": (cand.get("sha256") or "")[:8],
                "bytes": cand.get("bytes"),
                "mechanism": pairing.get("mechanism", ""),
                "runs": gate.get("runs") or {},
                "combined": gate.get("combined") or {},
                "readings": gate.get("readings") or {},
                "released": gate.get("released_to_jb"),
                "not_run": sorted(p.name for p in (beta_dir / "not_run_gate").glob("*.json")) if (beta_dir / "not_run_gate").is_dir() else [],
                "jb_a": None,
                "jb_a_protocol": None,
                "jb_a_rate": None,
            }
            jb = read_json(beta_dir / "gates" / "JB-A" / "JB_A_DECISION.json")
            if jb:
                row["jb_a"] = jb
                row["jb_a_protocol"] = jb.get("protocol_compliant", True)
                row["jb_a_rate"] = jb.get("manual_refusal_rate_on_completed")
            rows.append(row)
    return rows


def fmt_runs(row: dict) -> str:
    runs = row["runs"]
    if not runs:
        return "—"
    parts = []
    for name in sorted(runs, key=lambda n: (len(n), n)):
        info = runs[name]
        ratio = info.get("ratio")
        total = info.get("judged_total")
        denom = str(total) if total is not None else "?"
        parts.append(
            f"{name.replace('A_', '')} {info.get('passed')}/{denom}"
            + (f" ({ratio:.0%})" if isinstance(ratio, (int, float)) else "")
        )
    return " · ".join(parts)


def strict_from_runs(row: dict):
    """Recompute the strict reading from the per-run records.

    Versions decided before the strict reading existed have no stored flag; the
    rule is mechanical (pooled ratio and the worse run must both reach half), so
    it can be recomputed from the same numbers.
    """
    runs = row["runs"]
    if not runs:
        return None, None
    ratios = [info.get("ratio") for info in runs.values() if isinstance(info.get("ratio"), (int, float))]
    if not ratios:
        return None, None
    combined = row["combined"].get("ratio")
    worst = min(ratios)
    if not isinstance(combined, (int, float)):
        return worst, None
    return worst, (combined >= 0.5 and worst >= 0.5)


def main() -> int:
    parser = argparse.ArgumentParser(description="Build the 6.2 dual-line version ledger.")
    parser.add_argument("--out", default=None)
    parser.add_argument("--epoch", default=EPOCH_DEFAULT,
                        help="epoch evidence directory name under reports/")
    args = parser.parse_args()
    global LINES, OUT_DEFAULT
    if args.epoch != EPOCH_DEFAULT:
        LINES = ROOT / "reports" / args.epoch / "lines"
        OUT_DEFAULT = ROOT / "reports" / args.epoch / "VERSION_LEDGER.md"
    out_path = Path(args.out).expanduser() if args.out else OUT_DEFAULT

    rows = collect()
    lines = [
        f"# gpt-6.2 双线版本账本（{args.epoch.rsplit('-', 1)[-1]}）",
        "",
        "本表由 `scripts/build_gpt62_version_ledger.py` 从各版本的记录文件生成，与逐版本证据同源。",
        "口径：A 门禁按人工复核，每轮 fresh run 4 例（provider 拦截与缺失响应单列、不计入分母）；",
        "`strict` 口径＝合并口径与两轮里**较差的一轮**都必须 ≥ 一半（用户 2026-11-18 规则）。",
        "JB-A 拒答率＝`manual_refusal_true / completed_target`，越低越好。",
        "",
    ]
    for line in sorted({r["line"] for r in rows}):
        lines += [f"## {line}", "",
                  "| 版本 | 候选 SHA | 字节 | 机制 | A 门禁（每轮） | 合并 | strict | 放行 | JB-A 拒答率 | 下游 |",
                  "|---|---|---|---|---|---|---|---|---|---|"]
        for row in [r for r in rows if r["line"] == line]:
            readings = row["readings"]
            combined = row["combined"]
            worst, strict_flag = strict_from_runs(row)
            if strict_flag is None:
                strict_flag = readings.get("released_under_strict_reading")
            jb = row["jb_a_rate"]
            if jb is None:
                jb_cell = "—"
            else:
                tag = "" if row["jb_a_protocol"] else "（out_of_protocol）"
                jb_cell = f"{jb:.2%}{tag}"
            nr = ", ".join(row["not_run"]) if row["not_run"] else "—"
            lines.append(
                f"| {row['beta']} | `{row['sha']}` | {row['bytes']} | {row['mechanism'] or '—'} | "
                f"{fmt_runs(row)} | "
                f"{combined.get('passed', '—')}/{combined.get('judged_total', '—')}"
                + (f" ({combined['ratio']:.0%})" if isinstance(combined.get("ratio"), (int, float)) else "")
                + f" | {'True' if strict_flag else ('False' if strict_flag is not None else '—')}"
                + (f"（较差一轮 {worst:.0%}）" if isinstance(worst, (int, float)) else "")
                + f" | {'是' if row['released'] else '否'} | {jb_cell} | {nr} |"
            )
        lines.append("")

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    for _ in range(10):
        out.write_text("\n".join(lines) + "\n", encoding="utf-8")
        if out.is_file() and out.stat().st_size > 0:
            break
        time.sleep(1)
    print(f"ledger written: {out} ({len(rows)} versions)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
