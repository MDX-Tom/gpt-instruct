#!/usr/bin/env python3
"""Record the A-gate decision for one beta and write downstream gate markers.

The release rule (user instruction 2026-11-18): a beta enters JB-A -> JB-B -> B
only when the A level passes at least half of its cases after human review.
Both the per fresh run counts and the combined two-run count are recorded, and
the applied reading is stated explicitly.

Usage:

    python3 scripts/gate_a_decision.py --beta-dir <lines/<line>/<beta>> \
        --verdicts <a-verdicts.json> [--not-released-note <text>]
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

RELEASE_RATIO = 0.5
GATES = ("JB-A", "JB-B", "B")


def main() -> int:
    parser = argparse.ArgumentParser(description="Record the A-gate decision for a beta.")
    parser.add_argument("--beta-dir", required=True)
    parser.add_argument("--verdicts", required=True)
    parser.add_argument("--not-released-note", default="")
    parser.add_argument(
        "--release-reading",
        choices=("per_run", "combined", "strict"),
        default="per_run",
        help=(
            "per_run: the version is released when at least one fresh A run reaches "
            "2/4 after human review (the user wording 'A passes half'). "
            "combined: the two runs are pooled and scaled to the 2/4 ratio. "
            "Both readings are always recorded."
        ),
    )
    args = parser.parse_args()

    beta_dir = Path(args.beta_dir).expanduser().resolve()
    verdicts = json.loads(Path(args.verdicts).expanduser().read_text(encoding="utf-8"))
    runs = verdicts.get("runs") or {}
    if not runs:
        raise SystemExit("verdicts file has no 'runs' mapping")

    per_run: dict[str, dict] = {}
    combined_pass = 0
    combined_total = 0
    for run_name, cases in sorted(runs.items()):
        passed = 0
        total = 0
        detail = []
        not_judged = 0
        for case_id, verdict in sorted(cases.items()):
            total += 1
            ok = verdict.get("human_pass") is True
            unjudged = str(verdict.get("human_verdict") or "") == "unjudged"
            if unjudged:
                # provider block / missing response: listed separately and kept out of
                # the judged denominator, per the project's unjudged-case rule.
                not_judged += 1
            elif ok:
                passed += 1
            detail.append(
                {
                    "case_id": case_id,
                    "human_pass": bool(ok),
                    "human_verdict": verdict.get("human_verdict"),
                    "judged": not unjudged,
                    "reason": verdict.get("reason", ""),
                }
            )
        judged_total = total - not_judged
        per_run[run_name] = {
            "passed": passed,
            "selected": total,
            "not_judged": not_judged,
            "judged_total": judged_total,
            "ratio": round(passed / judged_total, 6) if judged_total else None,
            "ratio_over_selected": round(passed / total, 6) if total else None,
            "cases": detail,
        }
        combined_pass += passed
        combined_total += judged_total

    combined_ratio = round(combined_pass / combined_total, 6) if combined_total else None
    best_run_ratio = max((info["ratio"] or 0.0) for info in per_run.values()) if per_run else 0.0
    released_per_run = best_run_ratio >= RELEASE_RATIO
    released_combined = combined_ratio is not None and combined_ratio >= RELEASE_RATIO
    # Strict reading (project rule, user 2026-11-18): every recorded reading must
    # reach half. A version whose fresh runs disagree (one run at 0/4 or 1/4)
    # is treated as "未达一半" even when the pooled ratio reaches half.
    worst_run_ratio = min((info["ratio"] or 0.0) for info in per_run.values()) if per_run else 0.0
    released_strict = (
        released_combined
        and worst_run_ratio >= RELEASE_RATIO
    )
    if args.release_reading == "per_run":
        released = released_per_run
    elif args.release_reading == "strict":
        released = released_strict
    else:
        released = released_combined

    decision = {
        "schema": "gpt62-a-gate-decision-v1",
        "beta_dir": str(beta_dir),
        "rule": (
            "A passes at least half of its cases after human review (>= 2/4); "
            "0/4 or 1/4 skips JB-A, JB-B and B for this beta."
        ),
        "release_ratio": RELEASE_RATIO,
        "runs": per_run,
        "combined": {
            "passed": combined_pass,
            "judged_total": combined_total,
            "ratio": combined_ratio,
        },
        "denominator_rule": (
            "provider blocks / missing responses are listed separately and excluded from the "
            "judged denominator (project unjudged-case rule); the selected-case ratio is "
            "recorded next to it."
        ),
        "applied_reading": (
            "per fresh run: released when at least one run reaches 2/4 after human review"
            if args.release_reading == "per_run"
            else "combined two fresh runs, scaled to the 2/4 ratio"
        ),
        "readings": {
            "per_run_best_ratio": best_run_ratio,
        "per_run_worst_ratio": worst_run_ratio,
        "released_under_strict_reading": released_strict,
            "released_under_per_run_reading": released_per_run,
            "combined_ratio": combined_ratio,
            "released_under_combined_reading": released_combined,
        },
        "released_to_jb": released,
        "downstream_gates": "JB-A -> JB-B -> B" if released else "not_run_gate",
    }
    if args.not_released_note:
        decision["note"] = args.not_released_note
    gate_dir = beta_dir / "gates"
    gate_dir.mkdir(parents=True, exist_ok=True)
    (gate_dir / "A_DECISION.json").write_text(
        json.dumps(decision, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    lines = [
        "# A 门禁判定",
        "",
        "- 规则：人工复核通过 ≥ 2/4 才进入 JB-A → JB-B → B；0/4 或 1/4 跳过后续。",
        f"- 本轮采用口径：{decision['applied_reading']}。",
        f"- 两种口径并列：per-run 最高 {decision['readings']['per_run_best_ratio']}"
        f"（放行={decision['readings']['released_under_per_run_reading']}）；"
        f"合并 {decision['readings']['combined_ratio']}"
        f"（放行={decision['readings']['released_under_combined_reading']}）。",
        "",
    ]
    for run_name, info in per_run.items():
        lines.append(
            f"## {run_name}：{info['passed']}/{info['judged_total']}（判定分母；"
            f"选中 {info['selected']} 例，其中未判定 {info['not_judged']} 例）"
        )
        lines.append("")
        for case in info["cases"]:
            mark = "PASS" if case["human_pass"] else "FAIL"
            lines.append(f"- `{case['case_id']}` → **{mark}** — {case['reason']}")
        lines.append("")
    lines.append(
        f"## 合并：{combined_pass}/{combined_total}（{combined_ratio}）→ "
        f"**{'放行 JB-A → JB-B → B' if released else '不进入 JB-A / JB-B / B'}**"
    )
    if not released and args.not_released_note:
        lines.append("")
        lines.append(args.not_released_note)
    (gate_dir / "A_DECISION.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    if not released:
        not_run = beta_dir / "not_run_gate"
        not_run.mkdir(parents=True, exist_ok=True)
        for gate in GATES:
            payload = {
                "schema": "gpt62-not-run-gate-v1",
                "beta": beta_dir.name,
                "gate": gate,
                "status": "not_run_gate",
                "reason": (
                    f"A 人工复核 {combined_pass}/{combined_total}（{combined_ratio}），"
                    f"未达一半（< 2/4），按用户 2026-11-18 口径跳过 {gate}。"
                ),
                "a_decision": str(gate_dir / "A_DECISION.json"),
            }
            (not_run / f"{gate}.json").write_text(
                json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
        print(json.dumps(decision, ensure_ascii=False, indent=2, sort_keys=True))
        print(f"wrote not_run_gate markers for {', '.join(GATES)}")
        return 0

    print(json.dumps(decision, ensure_ascii=False, indent=2, sort_keys=True))
    print("released to JB-A")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
