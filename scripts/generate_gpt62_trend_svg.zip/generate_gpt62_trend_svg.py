#!/usr/bin/env python3
"""Generate the gpt-6.2 dual-line iteration trend charts (SVG).

The charts read the recorded gate evidence only:

  A       gates/A_DECISION.json      combined reading of the fresh runs
  JB-A    gates/JB-A/...             manual review verdicts (1 - refusal rate)
  JB-B    diagnostics/JB-B-...       manual review verdicts (1 - refusal rate)
  B       gates/B/...                issue regression bank

A point is drawn for every version that has a recorded reading; versions
without a recorded reading are not plotted and are never counted as zero.

Usage:
    python3 scripts/generate_gpt62_trend_svg.py [--out-dir docs/images]
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EPOCHS = ["gpt62-dual-line-epoch1-2026-11-18", "gpt62-dual-line-epoch2-2026-11-19"]
LINES = ["gpt-6.2-astra", "gpt-6.2-sol"]
BETA_RE = re.compile(r"^e\d+b\d+$")

# Human conclusions recorded in the fact log instead of a per-run verdict file.
LOGGED = {
    ("gpt-6.2-sol", "e2b4"): {
        "JB-A": (5, 19, "codex/codex_report.md (2026-11-19, sol e2b4)"),
    },
}

PALETTE = {
    "light": {
        "bg": "#F5F3EE", "panel": "#FBFAF7", "border": "#D8D4CC", "grid": "#D8D4CC",
        "axis": "#8C8A84", "title": "#2E3437", "muted": "#6F7476", "axis_text": "#4E565A",
        "a": "#667C91", "jba": "#708C7A", "jbb": "#B07D62", "b": "#8C8A84",
    },
    "dark": {
        "bg": "#171A1D", "panel": "#1E2225", "border": "#3D4346", "grid": "#3D4346",
        "axis": "#777E81", "title": "#ECE8DF", "muted": "#AAA69E", "axis_text": "#D4D0C7",
        "a": "#9AAFC2", "jba": "#9BB19E", "jbb": "#C99C84", "b": "#777E81",
    },
}

TEXT = {
    "zh": {
        "x_title": "提示词版本",
        "y_title": "案例通过率",
        "legend": ["A cases", "JB-A cases", "JB-B cases", "B cases（未运行）"],
        "footer": "A：两次 fresh run 合并读数（分母 8，个别版本 12）；JB-A / JB-B：1 − 人工拒答率（真实合规 / 完成）；B 门禁在两条 6.2 线上未运行，无 B 点。",
    },
    "en": {
        "x_title": "Prompt version",
        "y_title": "Case pass rate",
        "legend": ["A cases", "JB-A cases", "JB-B cases", "B cases (not run)"],
        "footer": "A: two fresh runs merged (denominator 8, 12 on some versions); JB-A / JB-B: 1 − manual refusal rate (compliant / completed); the B gate has not run on either 6.2 line, so no B points.",
    },
}

FONT = "Charter,Georgia,Times New Roman,STSong,Songti SC,Noto Serif CJK SC,serif"
W, H = 1600, 880
PLOT_L, PLOT_R = 150.0, 1410.0
Y0, Y1 = 710.0, 160.0  # 0% .. 100%


def read_json(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def read_jsonl(path: Path) -> list[dict]:
    if not path.is_file():
        return []
    out = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            out.append(json.loads(line))
        except Exception:
            pass
    return out


def beta_sort(name: str) -> tuple[int, int]:
    match = re.search(r"e(\d+)b(\d+)", name)
    return (int(match.group(1)), int(match.group(2))) if match else (0, 0)


def suite_reading(run_dir: Path) -> tuple[int, int] | None:
    """Compliant / completed from the human review layer of one JB run."""
    if not run_dir.is_dir():
        return None
    verdicts: dict[str, dict] = {}
    for row in read_jsonl(run_dir / "manual-review.jsonl"):
        verdicts[str(row.get("case_id") or row.get("id") or "")] = row
    if not verdicts:
        blob = read_json(run_dir / "manual-verdicts-map.json")
        if isinstance(blob, dict):
            verdicts = blob
    if not verdicts:
        return None
    completed = 0
    refusal = 0
    for row in verdicts.values():
        if not isinstance(row, dict):
            continue
        if row.get("status") in ("interrupted_codex_exit", "provider_policy_block"):
            continue
        completed += 1
        if row.get("manual_refusal") is True:
            refusal += 1
    if not completed:
        return None
    return completed - refusal, completed


def find_run(beta_dir: Path, suite: str) -> Path | None:
    candidates = [beta_dir / "gates" / suite, beta_dir / "diagnostics" / f"{suite}-diagnostic"]
    candidates += sorted((beta_dir / "diagnostics").glob(f"{suite}*"))
    candidates += sorted((beta_dir / "gates").glob(f"{suite}*"))
    for path in candidates:
        if path.is_dir() and ((path / "manual-review.jsonl").is_file() or (path / "manual-verdicts-map.json").is_file()):
            return path
    return None


def a_reading(beta_dir: Path) -> tuple[int, int] | None:
    decision = read_json(beta_dir / "gates" / "A_DECISION.json")
    if not isinstance(decision, dict):
        return None
    combined = decision.get("combined") or {}
    passed = combined.get("passed")
    denominator = combined.get("judged_total")
    if denominator is None:
        denominator = combined.get("total")
    if passed is None or denominator is None:
        return None
    return passed, denominator


def collect_line(line: str) -> list[dict]:
    """One entry per version that carries a recorded reading, in version order."""
    versions: list[dict] = []
    seen: set[str] = set()
    for epoch in EPOCHS:
        line_dir = ROOT / "reports" / epoch / "lines" / line
        if not line_dir.is_dir():
            continue
        for beta_dir in sorted((p for p in line_dir.iterdir() if p.is_dir() and BETA_RE.match(p.name)),
                               key=lambda p: beta_sort(p.name)):
            beta = beta_dir.name
            if beta in seen:
                # The same version re-measured in a later window (same-window
                # anchor scans live under the older beta name); the version
                # keeps its canonical reading.
                continue
            entry = {"beta": beta, "a": a_reading(beta_dir), "jba": None, "jbb": None}
            logged = LOGGED.get((line, beta), {})
            jba_run = find_run(beta_dir, "JB-A")
            if jba_run:
                entry["jba"] = suite_reading(jba_run)
            elif "JB-A" in logged:
                entry["jba"] = logged["JB-A"][:2]
            jbb_run = find_run(beta_dir, "JB-B")
            if jbb_run:
                entry["jbb"] = suite_reading(jbb_run)
            if entry["a"] is None and entry["jba"] is None and entry["jbb"] is None:
                continue
            seen.add(beta)
            versions.append(entry)
    return versions


def esc(text: str) -> str:
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def y_of(ratio: float) -> float:
    return Y0 - ratio * (Y0 - Y1)


def x_of(index: int, count: int) -> float:
    if count <= 1:
        return PLOT_L
    return PLOT_L + index * (PLOT_R - PLOT_L) / (count - 1)


def marker_circle(x: float, y: float, color: str, panel: str) -> str:
    return (f'<circle cx="{x:.1f}" cy="{y:.1f}" r="7" fill="{color}" stroke="{panel}" stroke-width="2"/>')


def marker_square(x: float, y: float, color: str, panel: str) -> str:
    return (f'<rect x="{x - 7:.1f}" y="{y - 7:.1f}" width="14" height="14" rx="2" '
            f'fill="{color}" stroke="{panel}" stroke-width="2"/>')


def marker_diamond(x: float, y: float, color: str, panel: str) -> str:
    return (f'<polygon points="{x:.1f},{y - 8.5:.1f} {x + 8.5:.1f},{y:.1f} '
            f'{x:.1f},{y + 8.5:.1f} {x - 8.5:.1f},{y:.1f}" fill="{color}" stroke="{panel}" stroke-width="2"/>')


def render(line: str, versions: list[dict], lang: str, scheme: str) -> str:
    palette = PALETTE[scheme]
    text = TEXT[lang]
    slug = line.replace("gpt-6.2-", "")
    title = f"{line} A/JB 迭代通过率" if lang == "zh" else f"{line} A/JB Pass Trend"
    count = len(versions)
    span = f"{versions[0]['beta']}–{versions[-1]['beta']}" if count else ""
    subtitle = (f"{span} · A / JB-A / JB-B / B · 逐例人工结论" if lang == "zh"
                else f"{span} · A / JB-A / JB-B / B · per-case human review")

    out: list[str] = []
    add = out.append
    add(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" role="img" aria-labelledby="title desc">')
    add(f'<title id="title">{esc(title)}</title>')
    add(f'<desc id="desc">{esc(subtitle)}</desc>')
    add(f'<rect width="{W}" height="{H}" fill="{palette["bg"]}"/>')
    add(f'<rect x="55" y="110" width="1490" height="665" rx="4" fill="{palette["panel"]}" stroke="{palette["border"]}"/>')
    add(f'<g font-family="{FONT}">')
    add(f'<text x="780" y="60" text-anchor="middle" font-size="32" font-weight="500" fill="{palette["title"]}">{esc(title)}</text>')
    add(f'<text x="780" y="92" text-anchor="middle" font-size="20" fill="{palette["muted"]}">{esc(subtitle)}</text>')

    for step in range(0, 101, 20):
        y = Y0 - step / 100 * (Y0 - Y1)
        add(f'<line x1="{PLOT_L}" y1="{y:.1f}" x2="{PLOT_R}" y2="{y:.1f}" stroke="{palette["grid"]}" stroke-width="1"/>')
        add(f'<text x="132" y="{y + 9:.1f}" text-anchor="end" font-size="24" fill="{palette["axis_text"]}">{step}%</text>')
    add(f'<line x1="{PLOT_L}" y1="{Y1}" x2="{PLOT_L}" y2="{Y0}" stroke="{palette["axis"]}" stroke-width="1.5"/>')
    add(f'<line x1="{PLOT_L}" y1="{Y0}" x2="{PLOT_R}" y2="{Y0}" stroke="{palette["axis"]}" stroke-width="1.5"/>')

    for index, entry in enumerate(versions):
        x = x_of(index, count)
        add(f'<line x1="{x:.1f}" y1="{Y0}" x2="{x:.1f}" y2="716" stroke="{palette["axis"]}"/>')
        add(f'<text x="{x:.1f}" y="750" text-anchor="middle" font-size="18" fill="{palette["axis_text"]}">{entry["beta"]}</text>')

    add(f'<text x="780" y="815" text-anchor="middle" font-size="24" fill="{palette["axis_text"]}">{esc(text["x_title"])}</text>')
    add(f'<text x="40" y="435" transform="rotate(-90 40 435)" text-anchor="middle" font-size="24" fill="{palette["axis_text"]}">{esc(text["y_title"])}</text>')

    series = [
        ("a", palette["a"], "circle", None),
        ("jba", palette["jba"], "diamond", "10 7"),
        ("jbb", palette["jbb"], "square", None),
    ]
    drawn: dict[str, list[tuple[float, float, str]]] = {}
    for key, color, shape, dash in series:
        points = []
        for index, entry in enumerate(versions):
            reading = entry[key]
            if not reading:
                continue
            numerator, denominator = reading
            ratio = numerator / denominator
            x = x_of(index, count)
            y = y_of(ratio)
            points.append((x, y, f"{numerator}/{denominator}"))
        if not points:
            continue
        drawn[key] = points
        coords = " ".join(f"{x:.1f},{y:.1f}" for x, y, _ in points)
        dash_attr = f' stroke-dasharray="{dash}"' if dash else ""
        add(f'<polyline points="{coords}" fill="none" stroke="{color}" stroke-width="3.5" '
            f'stroke-linecap="round" stroke-linejoin="round"{dash_attr}/>')
        for x, y, _ in points:
            if shape == "circle":
                add(marker_circle(x, y, color, palette["panel"]))
            elif shape == "square":
                add(marker_square(x, y, color, palette["panel"]))
            else:
                add(marker_diamond(x, y, color, palette["panel"]))

    labels_by_x: dict[float, list[tuple[float, str, str]]] = {}
    for key, color, _, _ in series:
        for x, y, label in drawn.get(key, []):
            offset = {"a": 50, "jba": -22, "jbb": 34}[key]
            labels_by_x.setdefault(x, []).append((y + offset, color, label))

    for x, items in labels_by_x.items():
        items.sort()
        placed: list[tuple[float, str, str]] = []
        for y, color, label in items:
            if placed and y - placed[-1][0] < 26:
                y = placed[-1][0] + 26
            placed.append((y, color, label))
        overflow = placed[-1][0] - 694
        if overflow > 0:
            placed = [(y - overflow, color, label) for y, color, label in placed]
        for y, color, label in placed:
            add(f'<text x="{x:.1f}" y="{y:.1f}" text-anchor="middle" font-size="16" '
                f'font-weight="500" fill="{color}">{label}</text>')

    legend_x = 740.0
    swatches = [
        (palette["a"], "circle", None, text["legend"][0], 128),
        (palette["jba"], "diamond", "10 7", text["legend"][1], 168),
        (palette["jbb"], "square", None, text["legend"][2], 168),
        (palette["b"], "none", "6 8", text["legend"][3], 0),
    ]
    for color, shape, dash, label, advance in swatches:
        add(f'<line x1="{legend_x:.1f}" y1="135" x2="{legend_x + 34:.1f}" y2="135" stroke="{color}" stroke-width="3.5"'
            + (f' stroke-dasharray="{dash}"' if dash else "") + "/>")
        if shape == "circle":
            add(f'<circle cx="{legend_x + 17:.1f}" cy="135" r="7" fill="{color}"/>')
        elif shape == "square":
            add(f'<rect x="{legend_x + 10:.1f}" y="128" width="14" height="14" rx="2" fill="{color}"/>')
        elif shape == "diamond":
            add(f'<polygon points="{legend_x + 17:.1f},126.5 {legend_x + 25.5:.1f},135 '
                f'{legend_x + 17:.1f},143.5 {legend_x + 8.5:.1f},135" fill="{color}"/>')
        add(f'<text x="{legend_x + 45:.1f}" y="144" font-size="24" fill="{palette["axis_text"]}">{esc(label)}</text>')
        legend_x += advance

    add(f'<text x="780" y="858" text-anchor="middle" font-size="16" fill="{palette["muted"]}">{esc(text["footer"])}</text>')
    add("</g>")
    add("</svg>")
    return "".join(out)


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate the gpt-6.2 trend charts.")
    parser.add_argument("--out-dir", default=str(ROOT / "docs" / "images"))
    args = parser.parse_args()
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    for line in LINES:
        versions = collect_line(line)
        slug = line.replace("gpt-6.2-", "")
        for lang in ("zh", "en"):
            for scheme in ("light", "dark"):
                svg = render(line, versions, lang, scheme)
                path = out_dir / f"gpt62-{slug}-ab-trend-{lang}-{scheme}.svg"
                path.write_text(svg, encoding="utf-8")
                print(f"[written] {path.relative_to(ROOT)} ({len(svg)} bytes, {len(versions)} versions)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
