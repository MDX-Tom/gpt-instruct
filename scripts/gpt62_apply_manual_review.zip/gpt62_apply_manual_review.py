#!/usr/bin/env python3
"""Materialize a per-run manual review file from the reviewed template.

Usage:

    python3 scripts/gpt62_apply_manual_review.py --run-dir <run-dir> [--verify]

The template holds the human verdict for every case after reading the full
response. This helper copies the verdicts that belong to the run, verifies that
the run actually produced a response for every case, and refuses to write a
verdict for a case with no response (such a case stays unjudged).
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
TEMPLATE = (
    PROJECT_ROOT
    / "reports"
    / "gpt62-dual-line-epoch1-2026-11-18"
    / "manual_review_template.json"
)


def read_jsonl(path: Path) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    with path.open("r", encoding="utf-8") as handle:
        for number, line in enumerate(handle, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise SystemExit(f"{path}: invalid JSONL at line {number}: {exc}") from exc
    return rows


def main() -> int:
    parser = argparse.ArgumentParser(description="Apply the reviewed verdicts to one run.")
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--template", default=str(TEMPLATE))
    args = parser.parse_args()

    run_dir = Path(args.run_dir).expanduser().resolve()
    results_path = run_dir / "results.jsonl"
    if not results_path.is_file():
        raise SystemExit(f"missing results: {results_path}")

    template = json.loads(Path(args.template).expanduser().read_text(encoding="utf-8"))
    verdicts = {str(row["case_id"]): row for row in template["rows"]}
    results = read_jsonl(results_path)

    out_rows: list[dict[str, object]] = []
    problems: list[str] = []
    for row in results:
        case_id = str(row.get("case_id"))
        template_row = verdicts.get(case_id)
        if template_row is None:
            problems.append(f"{case_id}: no reviewed verdict in the template")
            continue
        if not str(row.get("response") or ""):
            problems.append(f"{case_id}: no response captured; case stays unjudged")
            continue
        out_rows.append(
            {
                "case_id": case_id,
                "manual_verdict": template_row["manual_verdict"],
                "manual_note": template_row["manual_note"],
                "manual_bank": row.get("bank"),
                "response_sha256": row.get("response_sha256"),
                # AGENTS.md §3.1 (2026-11-19): the full-text review contract fields.
                "task_completion": str(template_row.get("task_completion") or ""),
                "task_completion_note": str(template_row.get("task_completion_note") or ""),
                "refusal_kind": str(template_row.get("refusal_kind") or ""),
                "refusal_evidence": str(template_row.get("refusal_evidence") or ""),
                "weak_point": str(template_row.get("weak_point") or ""),
                "reviewed_by": str(template_row.get("reviewed_by") or "main-thread"),
            }
        )

    out_path = run_dir / "manual-review.jsonl"
    out_path.write_text(
        "".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in out_rows),
        encoding="utf-8",
    )
    print(out_path)
    print(f"manual verdicts written: {len(out_rows)}")
    for problem in problems:
        print(f"WARN: {problem}")
    return 1 if problems else 0


if __name__ == "__main__":
    raise SystemExit(main())
