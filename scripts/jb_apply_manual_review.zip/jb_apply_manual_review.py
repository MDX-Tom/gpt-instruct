#!/usr/bin/env python3
"""Materialize a jbb-human-review-v2 file from reviewed verdicts and score the run.

Usage:

    python3 scripts/jb_apply_manual_review.py --run-dir <jb-run-dir> \
        --verdicts <verdicts.json>

``verdicts.json`` maps ``case_id`` to an object with the human fields:

    {"jbb.005": {"manual_refusal": true, "manual_cheating": false,
                 "manual_protocol_violation": false,
                 "manual_unsafe": false, "manual_safe": true,
                 "finding": "…具体判断…"}, …}

Cases that are provider blocked or otherwise not completed are recorded as
unjudged and never enter a rate denominator. The official label stays ``null``
when the upstream judge did not run; no label is inferred.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def read_jsonl(path: Path) -> list[dict]:
    rows: list[dict] = []
    with path.open("r", encoding="utf-8") as handle:
        for number, line in enumerate(handle, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise SystemExit(f"{path}: invalid JSONL at line {number}: {exc}") from exc
    return rows


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description="Apply human JB verdicts and score a run.")
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--verdicts", required=True)
    parser.add_argument("--output-name", default="manual-review.jsonl")
    args = parser.parse_args()

    run_dir = Path(args.run_dir).expanduser().resolve()
    results_path = run_dir / "results.unjudged.jsonl"
    if not results_path.is_file():
        raise SystemExit(f"missing results: {results_path}")
    verdicts = json.loads(Path(args.verdicts).expanduser().read_text(encoding="utf-8"))
    rows = read_jsonl(results_path)

    out_rows: list[dict] = []
    problems: list[str] = []
    for row in rows:
        case_id = str(row.get("case_id"))
        status = str(row.get("status") or "")
        if status != "completed":
            continue
        verdict = verdicts.get(case_id)
        if verdict is None:
            problems.append(f"{case_id}: no human verdict")
            continue
        # The reviewable text is the FULL raw_response. The runner also stores a
        # truncated excerpt in the "response" field (and in cases/<id>/result.json);
        # that excerpt must never be the sole basis of a human verdict.
        raw_response = str(row.get("raw_response") or row.get("response") or "")
        case_excerpt = str(row.get("response") or "")
        reviewed_chars = int(verdict.get("reviewed_chars") or len(raw_response))
        tail_reviewed = bool(verdict.get("tail_reviewed"))
        out_rows.append(
            {
                "schema": "jbb-human-review-v2",
                "case_id": case_id,
                "target_status": status,
                "official_label": row.get("official_label"),
                "manual_refusal": bool(verdict.get("manual_refusal", False)),
                "manual_cheating": bool(verdict.get("manual_cheating", False)),
                "manual_protocol_violation": bool(verdict.get("manual_protocol_violation", False)),
                "manual_unsafe": bool(verdict.get("manual_unsafe", False)),
                "manual_safe": bool(verdict.get("manual_safe", False)),
                "raw_response_sha256": sha256_text(raw_response),
                "response_sha256": sha256_text(raw_response),
                "case_record_excerpt_sha256": sha256_text(case_excerpt),
                "case_record_excerpt_chars": len(case_excerpt),
                "full_response_chars": len(raw_response),
                "reviewed_response_chars": reviewed_chars,
                "reviewed_full_raw_response": reviewed_chars >= len(raw_response),
                "tail_reviewed": tail_reviewed,
                "reviewed_visible_150_token_response": True,
                "evidence_path": f"cases/{case_id}/result.json",
                "full_evidence_path": "results.unjudged.jsonl",
                "finding": str(verdict.get("finding") or ""),
                "fulfillment_class": str(verdict.get("fulfillment_class") or ""),
                "fulfillment_note": str(verdict.get("fulfillment_note") or ""),
                "refusal_type": str(verdict.get("refusal_type") or ""),
                "safe_redirect_quality": str(verdict.get("safe_redirect_quality") or ""),
                "review_basis": str(verdict.get("review_basis") or ""),
                # AGENTS.md §3.1 (2026-11-19): the full-text review contract fields.
                "task_completion": str(verdict.get("task_completion") or ""),
                "task_completion_note": str(verdict.get("task_completion_note") or ""),
                "refusal_kind": str(verdict.get("refusal_kind") or ""),
                "refusal_evidence": str(verdict.get("refusal_evidence") or ""),
                "weak_point": str(verdict.get("weak_point") or ""),
                "reviewed_by": str(verdict.get("reviewed_by") or "main-thread"),
            }
        )

    manual_path = run_dir / args.output_name
    manual_path.write_text(
        "".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in out_rows),
        encoding="utf-8",
    )
    print(manual_path)
    print(f"manual rows written: {len(out_rows)}")
    for problem in problems:
        print(f"WARN: {problem}")

    review = subprocess.run(
        [
            sys.executable,
            str(PROJECT_ROOT / "scripts" / "review_jailbreakbench.py"),
            str(results_path),
            str(manual_path),
            "--output-dir",
            str(run_dir / "review"),
        ],
        capture_output=True,
        text=True,
    )
    sys.stdout.write(review.stdout)
    sys.stderr.write(review.stderr)
    if review.returncode != 0:
        return review.returncode
    summary = run_dir / "review" / "summary.json"
    if summary.is_file():
        print(summary.read_text(encoding="utf-8"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
