#!/usr/bin/env python3
"""Per-category breakdown of a reviewed JailbreakBench run.

The suite-level refusal rate hides where the refusals are concentrated. This
tool groups the human verdicts by the benchmark's own behavior categories and
reports, per category: selected / completed / manual refusals / refusal rate on
completed, plus the fulfillment classes and the unjudged case ids.

Usage:

    python3 scripts/jb_category_profile.py --run-dir <jb-run-dir> \
        [--out <path.json>] [--compare-run-dir <other-run-dir>]
"""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path


def read_jsonl(path: Path) -> list[dict]:
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for number, line in enumerate(handle, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise SystemExit(f"{path}: invalid JSONL at line {number}: {exc}") from exc
    return rows


def profile(run_dir: Path) -> dict:
    results = read_jsonl(run_dir / "results.unjudged.jsonl")
    manual_path = run_dir / "manual-review.jsonl"
    manual = {}
    if manual_path.is_file():
        manual = {str(row.get("case_id")): row for row in read_jsonl(manual_path)}

    categories: dict[str, dict] = defaultdict(
        lambda: {
            "selected": 0,
            "completed": 0,
            "unjudged": 0,
            "manual_refusal": 0,
            "fulfillment": Counter(),
            "unjudged_case_ids": [],
            "not_completed_case_ids": [],
        }
    )
    for row in results:
        category = str(row.get("category") or "unknown")
        entry = categories[category]
        case_id = str(row.get("case_id"))
        entry["selected"] += 1
        status = str(row.get("status") or "")
        if status != "completed":
            entry["not_completed_case_ids"].append(case_id)
            entry["unjudged"] += 1
            continue
        entry["completed"] += 1
        annotation = manual.get(case_id)
        if annotation is None:
            entry["unjudged"] += 1
            entry["unjudged_case_ids"].append(case_id)
            continue
        if annotation.get("manual_refusal") is True:
            entry["manual_refusal"] += 1
        entry["fulfillment"][str(annotation.get("fulfillment_class") or "unknown")] += 1

    out_categories = {}
    for category, entry in sorted(categories.items()):
        completed = entry["completed"]
        out_categories[category] = {
            "selected": entry["selected"],
            "completed": completed,
            "unjudged": entry["unjudged"],
            "manual_refusal": entry["manual_refusal"],
            "refusal_rate_on_completed": (
                round(entry["manual_refusal"] / completed, 6) if completed else None
            ),
            "fulfillment": dict(entry["fulfillment"]),
            "unjudged_case_ids": entry["unjudged_case_ids"],
            "not_completed_case_ids": entry["not_completed_case_ids"],
        }

    total_completed = sum(e["completed"] for e in out_categories.values())
    total_refusal = sum(e["manual_refusal"] for e in out_categories.values())
    return {
        "schema": "gpt62-jb-category-profile-v1",
        "run_dir": str(run_dir),
        "selected": len(results),
        "completed": total_completed,
        "manual_refusal": total_refusal,
        "refusal_rate_on_completed": (
            round(total_refusal / total_completed, 6) if total_completed else None
        ),
        "categories": out_categories,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Per-category profile of a reviewed JB run.")
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--compare-run-dir", default=None)
    parser.add_argument("--out", default=None)
    args = parser.parse_args()

    run_dir = Path(args.run_dir).expanduser().resolve()
    payload = profile(run_dir)
    if args.compare_run_dir:
        payload["comparison"] = profile(Path(args.compare_run_dir).expanduser().resolve())

    if args.out:
        out_path = Path(args.out).expanduser()
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
    print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
