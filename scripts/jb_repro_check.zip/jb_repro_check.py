#!/usr/bin/env python3
"""Reproducibility check between two reviewed JB runs.

Used to answer the question the metric-noise work raises: when two independent
runs of the SAME candidate disagree on a case, is that a real behavioural
difference or run-to-run variance?

The tool reports, for the paired set of cases completed in both runs:
  - the refusal rate in each run,
  - the per-case refusal flips with their fulfillment classes,
  - the paired delta and the binomial noise scale at that denominator,
  - whether the explicitly flagged cases reproduce.

Usage:
    python3 scripts/jb_repro_check.py --run-a <dir> --run-b <dir> \
        [--focus jbb.060,jbb.093] [--out <path.json>]
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path


def read_jsonl(path: Path) -> list[dict]:
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            rows.append(json.loads(line))
    return rows


def load(run_dir: Path):
    results = {row["case_id"]: row for row in read_jsonl(run_dir / "results.unjudged.jsonl")}
    manual = {row["case_id"]: row for row in read_jsonl(run_dir / "manual-review.jsonl")}
    return results, manual


def main() -> int:
    parser = argparse.ArgumentParser(description="Reproducibility check between two reviewed JB runs.")
    parser.add_argument("--run-a", required=True)
    parser.add_argument("--run-b", required=True)
    parser.add_argument("--focus", default="", help="comma separated case ids to highlight")
    parser.add_argument("--out", default=None)
    args = parser.parse_args()

    run_a = Path(args.run_a).expanduser().resolve()
    run_b = Path(args.run_b).expanduser().resolve()
    res_a, man_a = load(run_a)
    res_b, man_b = load(run_b)
    focus = [c.strip() for c in args.focus.split(",") if c.strip()]

    paired = [
        cid for cid in res_b
        if res_b[cid].get("status") == "completed" and cid in res_a
        and res_a[cid].get("status") == "completed" and cid in man_a and cid in man_b
    ]
    ref_a = sum(1 for cid in paired if man_a[cid].get("manual_refusal") is True)
    ref_b = sum(1 for cid in paired if man_b[cid].get("manual_refusal") is True)
    rate_a = ref_a / len(paired) if paired else None
    rate_b = ref_b / len(paired) if paired else None
    sd = math.sqrt(len(paired) * rate_a * (1 - rate_a)) if paired and rate_a is not None else None

    flips = []
    for cid in sorted(paired):
        a = man_a[cid].get("manual_refusal")
        b = man_b[cid].get("manual_refusal")
        if a != b:
            flips.append({
                "case_id": cid,
                "a_refusal": a, "b_refusal": b,
                "a_class": man_a[cid].get("fulfillment_class"),
                "b_class": man_b[cid].get("fulfillment_class"),
            })

    focus_rows = []
    for cid in focus:
        a_state = man_a.get(cid, {}).get("manual_refusal")
        b_state = man_b.get(cid, {}).get("manual_refusal")
        focus_rows.append({
            "case_id": cid,
            "a_status": res_a.get(cid, {}).get("status"),
            "b_status": res_b.get(cid, {}).get("status"),
            "a_refusal": a_state, "b_refusal": b_state,
            "a_class": man_a.get(cid, {}).get("fulfillment_class"),
            "b_class": man_b.get(cid, {}).get("fulfillment_class"),
            "reproduced": (
                "both_completed_same_label" if (a_state is not None and a_state == b_state)
                else ("both_completed_different_label" if (a_state is not None and b_state is not None)
                      else "not_comparable")
            ),
        })

    # L4 (2026-11-19): the blocked counts of both sides are part of every
    # cross-version comparison. A provider block is a terminal transport
    # outcome, not a model refusal, and it randomly shrinks the denominator.
    def blocked_counts(run_dir: Path) -> dict[str, int]:
        counts: dict[str, int] = {}
        results_path = run_dir / "results.unjudged.jsonl"
        if not results_path.is_file():
            return counts
        for row in read_jsonl(results_path):
            status = str(row.get("status") or "")
            if status != "completed":
                counts[status] = counts.get(status, 0) + 1
        return counts

    payload = {
        "schema": "gpt62-jb-repro-check-v1",
        "run_a": str(run_a), "run_b": str(run_b),
        "paired_cases": len(paired),
        "a_non_completed": blocked_counts(run_a),
        "b_non_completed": blocked_counts(run_b),
        "policy_blocked_note": (
            "provider blocks are terminal transport outcomes and are excluded from "
            "both the completed denominator and the manual refusal rate"
        ),
        "a": {"refusal": ref_a, "rate": round(rate_a, 6) if rate_a is not None else None,
              "completed": sum(1 for r in res_a.values() if r.get("status") == "completed")},
        "b": {"refusal": ref_b, "rate": round(rate_b, 6) if rate_b is not None else None,
              "completed": sum(1 for r in res_b.values() if r.get("status") == "completed")},
        "paired_delta_cases": ref_b - ref_a,
        "paired_delta_pp": round((rate_b - rate_a) * 100, 2) if rate_a is not None and rate_b is not None else None,
        "binomial_sd_cases": round(sd, 2) if sd else None,
        "delta_in_sd": round((ref_b - ref_a) / sd, 2) if sd else None,
        "flips": flips, "flip_count": len(flips),
        "focus": focus_rows,
        "reading": (
            f"配对 {len(paired)} 条：A {ref_a}/{len(paired)} = "
            f"{rate_a:.4f} → B {ref_b}/{len(paired)} = {rate_b:.4f}"
            + (f"，差 {ref_b - ref_a:+d} 个 case（{(rate_b - rate_a) * 100:+.2f} pp，约 {(ref_b - ref_a) / sd:+.2f} 个标准差）"
               if sd else "")
            + f"；逐 case 翻转 {len(flips)} 条。"
        ),
    }
    if args.out:
        out = Path(args.out).expanduser()
        for _ in range(10):
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
            if out.is_file():
                break
            time.sleep(1)
    print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
